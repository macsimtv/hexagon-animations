class Hexagon {
    constructor(x, y, size, app) {
        this.x = x;
        this.y = y;
        this.size = size;

        this.hexagonPointsCordinates = [];
        this.circles = [];

        this.isAnimated = true;
        this.isHovered = false;
        this.isClicked = false;

        this.hexagon;
        this.container;

        this.app = app;

        // Random 1 or -1
        this.direction = Math.floor(Math.random() * 2) === 0 ? 1 : -1;

        this._init();
    }

    _init() {

        this.container();
        this.draw();
        this.app.ticker.add(this.animate.bind(this));
        this.isAnimated = true;
    }

    container() {
        // Create container
        this.container = new PIXI.Container();
        this.container.sortableChildren = true;

        this.app.stage.addChild(this.container)
    }

    draw() {
        for (let side = 0; side < 6; side++) {
            this.hexagonPointsCordinates[side] = new PIXI.Point(this.size * Math.cos(side * 2 * Math.PI / 6), this.size * Math.sin(side * 2 * Math.PI / 6));
        }

        this.hexagon = new PIXI.Graphics();
        this.hexagon.beginFill(0x00000000);
        this.hexagon.lineStyle(1, 0x7a736a);
        this.hexagon.drawPolygon(this.hexagonPointsCordinates);
        this.hexagon.endFill();

        this.hexagon.buttonMode = true;
        this.hexagon.interactive = true;

        this.hexagon.zIndex = 1;

        this.hexagon.on('mouseover', () => {
            this.isHovered = true;
        });

        this.hexagon.on('mouseout', () => {
            this.isHovered = false;
        });

        this.drawCircles();
        this.addToFrame.bind(this)();
    }

    drawCircles() {
        for (let corner of this.hexagonPointsCordinates) {
            let pointCoordinate = {
                x: corner.x,
                y: corner.y
            }

            // Draw circle
            let circle = new PIXI.Graphics();
            circle.beginFill(0xbbbab7);
            circle.drawCircle(pointCoordinate.x, pointCoordinate.y, 2);
            circle.endFill();

            circle.zIndex = 2;

            this.circles.push(circle);
        }
    }  
    
    addToFrame() {
        this.container.addChild(this.hexagon);

        for (let circle of this.circles) {
            this.container.addChild(circle);
        }

        this.container.x = this.x;
        this.container.y = this.y;
    }

    animate() {
        if (!this.isAnimated) {
            return;
        }

        let speed = 0.005;
        let direction = this.direction;
        if(this.isHovered && this.container.scale.x > 0.9) {
            this.container.scale.x -= speed;
            this.container.scale.y -= speed;
            this.container.rotation += speed * direction;
        } else if(!this.isHovered && this.container.scale.x < 1) {
                this.container.scale.x += speed;
                this.container.scale.y += speed;
                this.container.rotation -= speed * direction;
        }
    }
}