// Canva
const canvas = document.getElementById('graphic');

// View
const ratio = 1.25;

let _w = window.innerWidth;
let _h = window.innerHeight;

const app = new PIXI.Application({
    view: canvas,
    width: _w / ratio,
    height: _h / ratio,
});

// Resize
window.addEventListener('resize', () => {
    _w = window.innerWidth;
    _h = window.innerHeight;
    app.renderer.resize(_w / ratio, _h / ratio);
});

const x = app.screen.width / 2;
const y = app.screen.height / 2;

const size = 50;

let hexagons = [];

for(let i = 0; i < 2; i++) {
    hexagons.push(new Hexagon(x, y + (i * (size * 2 - (size / 4))), size, app));
}

for(let i = 0; i < 1; i++) {
    hexagons.push(new Hexagon(x + size * 2, y + size * 2 - (size), size, app));
}

// Animation
app.ticker.add(animate);

function animate() {

}